/*
 * sleep_routines.h
 *
 *  Created on: Sep 21, 2021
 *      Author: Terence Williams
 */

/**************************************************************************
* @file sleep_routines.h
***************************************************************************
* @section License
* <b>(C) Copyright 2015 Silicon Labs, http://www.silabs.com</b>
***************************************************************************
*
* Permission is granted to anyone to use this software for any purpose,
* including commercial applications, and to alter it and redistribute it
* freely, subject to the following restrictions:
*
* 1. The origin of this software must not be misrepresented; you must not
* claim that you wrote the original software.
* 2. Altered source versions must be plainly marked as such, and must not be
* misrepresented as being the original software.
* 3. This notice may not be removed or altered from any source distribution.
*
* DISCLAIMER OF WARRANTY/LIMITATION OF REMEDIES: Silicon Labs has no
* obligation to support this Software. Silicon Labs is providing the
* Software "AS IS", with no express or implied warranties of any kind,
* including, but not limited to, any implied warranties of merchantability
* or fitness for any particular purpose or warranties against infringement
* of any proprietary rights of a third party.
*
* Silicon Labs will not be liable for any consequential, incidental, or
* special damages, or any other relief, or for any claim by any third party,
* arising from your use of this Software.
*
**************************************************************************/

//***********************************************************************************
// Include files
//***********************************************************************************


#ifndef HEADER_FILES_SLEEP_ROUTINES_H_
#define HEADER_FILES_SLEEP_ROUTINES_H_


/* System include statements */
#include <stdint.h>

/* Silicon Labs include statements */
#include "em_assert.h"
#include "em_core.h"
#include "em_emu.h"

/* The developer's include statements */
// #include "sleep_routines.h"

//***********************************************************************************
// defined files
//***********************************************************************************
#define EM0 0
#define EM1 1
#define EM2 2
#define EM3 3
#define EM4 4
#define MAX_ENERGY_MODES 5

//***********************************************************************************
// global variables
//***********************************************************************************


//***********************************************************************************
// function prototypes
//***********************************************************************************

void sleep_open(void);
// Initialize the sleep_routines static private array, lowest_energy_mode[], to all zeroes

void sleep_block_mode(uint32_t EM);
//Utilized by a peripheral to prevent the Mighty Gecko from going into that sleep mode while
// the peripheral is active. It will increment the associated array
// element in lowest_energy_mode[] by one.

void sleep_unblock_mode(uint32_t EM);
// Utilized to release the processor from going into a sleep mode with a peripheral that is
// no longer active. It will decrement the associated array element in
// lowest_energy_mode[] by one.

void enter_sleep(void);
// Function that will enter the appropriate
// sleep Energy Mode based on the first non-zero array element in
// lowest_energy_mode[].

uint32_t current_block_energy_mode(void);
// Function that returns which energy mode that the current system cannot enter,
// the first non-zero array element in lowest_energy_mode[].

#endif /* HEADER_FILES_SLEEP_ROUTINES_H_ */
