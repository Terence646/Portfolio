//***********************************************************************************
// Include files
//***********************************************************************************
#ifndef HEADER_FILES_I2C_H_
#define HEADER_FILES_I2C_H_


/* System include statements */


/* Silicon Labs include statements */

//#include "em_cmu.h"
//#include "em_assert.h"

#include "em_i2c.h"
#include "em_cmu.h"
#include "sleep_routines.h"
#include "scheduler.h"
/* The developer's include statements */


//***********************************************************************************
// defined files
//***********************************************************************************
//#define I2C_FREQ_STANDARD_MAX 100000
//#define I2C_FREQ_FAST_MAX     400000
//#define I2C_FREQ_FASTPLUS_MAX 1000000

//***********************************************************************************
// global variables
//***********************************************************************************

typedef struct{
  bool                      enable;         //Enable I2C peripheral when initialization completed.
  bool                      master;         //Set to master (true) or slave (false) mode.
  uint32_t                  refFreq;        //I2C reference clock assumed when configuring bus frequency setup.
  uint32_t                  freq;           //(Max) I2C bus frequency to use.
  I2C_ClockHLR_TypeDef      clhr;           //Clock low/high ratio control.
  uint32_t                  out_pin_routeSDA; // out 0 route to gpio port/pin
  uint32_t                  out_pin_routeSCL; // out 1 route to gpio port/pin
  bool                      out_pin_SDA_en;     // enable out 0 route
  bool                      out_pin_SCL_en;     // enable out 1 route

}I2C_OPEN_STRUCT;



typedef enum{
  initialize, //initialize write
  send_DA,          //send device address
  send_RA,          //send register address
  transfer_data,    // Data Transfer Initiated
  send_stop,        //send stop
}DEFINED_STATES;


typedef struct{
  DEFINED_STATES       Current_i2c_State;
  I2C_TypeDef          *i2c;
  bool                 read_true; // 0 == Write;  1 == Read
  uint32_t             numofBytes;  // Number of Bytes
  uint32_t             DeviceAddress;   //Device address
  uint32_t             RegisterAddress; //Register Address
  volatile bool                 busy;        // 0 = Not busy, 1 = busy
  uint32_t             callback;      // Callback events
  uint32_t             *StoreData;  // Store to store read result or to get the write data
}I2C_STATE_MACHINE;


//***********************************************************************************
// global function prototypes
//***********************************************************************************
void i2c_open(I2C_TypeDef *i2c, I2C_OPEN_STRUCT *i2c_setup);

void I2C0_IRQHandler(void);
void I2C1_IRQHandler(void);

void I2C_Start(I2C_TypeDef *i2c, bool read_true, uint32_t numofBytes, uint32_t DeviceAddress,
               uint32_t RegisterAddress, uint32_t callback, uint32_t *StoreData);

void i2c_ack_sm(I2C_STATE_MACHINE *i2c_sm);
void i2c_read_sm(I2C_STATE_MACHINE *i2c_sm);
void i2c_stop_sm(I2C_STATE_MACHINE *i2c_sm);

#endif /* HEADER_FILES_I2C_H_ */
