//***********************************************************************************
// Include files
//***********************************************************************************
#ifndef HEADER_FILES_SI1133_H_
#define HEADER_FILES_SI1133_H_


/* System include statements */


/* Silicon Labs include statements */

//#include "em_cmu.h"
//#include "em_assert.h"

#include "em_i2c.h"
#include "em_cmu.h"
#include "i2c.h"
#include "HW_delay.h"
#include "brd_config.h"
#include "app.h"

/* The developer's include statements */

#define DEVICEADDRESS 0x55
//***********************************************************************************
// defined files
//***********************************************************************************

//***********************************************************************************
// global variables
//***********************************************************************************


//***********************************************************************************
// global function prototypes
//***********************************************************************************
void Si1133_i2c_open(void);
void Si1133_read(uint32_t RegisterAddress,uint32_t NumofBytes, uint32_t callback);
uint32_t Si113_get_partID(void);


#endif /* HEADER_FILES_SI1133_H_ */


