/**
 * @file i2c.c
 * @author Terence Williams
 * @date 10/05/21
 * @brief
 *
 */

//***********************************************************************************
// Include files
//***********************************************************************************
#include "Si1133.h"
//***********************************************************************************
// defined files
//***********************************************************************************


//***********************************************************************************
// global variables
//***********************************************************************************



//***********************************************************************************
// private variables
//***********************************************************************************

static uint32_t  Si1133_read_result;

//***********************************************************************************
// function prototypes
//***********************************************************************************


//***********************************************************************************
// private functions
//***********************************************************************************

/***************************************************************************//**
 * @brief
 *  Initializing our Si1133 data, so that the Master Mighty Gecko can communicate with the Si1133 sensor.
 *
 * @details
 *  Passing in the I2C struct, we can store each required parameter to fill our Si1133
 *  sensor with required data defined in the HAL documentation and Si1133 Datasheet.
 *
 * @note
 *  Called in app.c when opening all other peripherals and drivers.
 *
 * @param
 *  I2C_TypeDef Struct with pointer *i2c.
 *
 ******************************************************************************/

void Si1133_i2c_open(){
  I2C_OPEN_STRUCT   i2c_setup_struct;

  timer_delay(30); //30ms Delay for startup time
  i2c_setup_struct.enable = true;         //Enable I2C peripheral when initialization completed.
  i2c_setup_struct.master = true;         //Set to master (true) or slave (false) mode.
  i2c_setup_struct.refFreq = 0;        //I2C reference clock assumed when configuring bus frequency setup.
  i2c_setup_struct.freq = I2C_FREQ_FAST_MAX;           //(Max) I2C bus frequency to use.
  i2c_setup_struct.clhr = i2cClockHLRAsymetric;           //Clock low/high ratio control.
  i2c_setup_struct.out_pin_routeSDA = I2C_ROUTELOC0_SCLLOC_LOC17; // out 0 route to gpio port/pin
  i2c_setup_struct.out_pin_routeSCL = I2C_ROUTELOC0_SDALOC_LOC17; // out 1 route to gpio port/pin
  i2c_setup_struct.out_pin_SDA_en = true;     // enable out 0 route
  i2c_setup_struct.out_pin_SCL_en = true;     // enable out 1 route

  i2c_open(I2C1,&i2c_setup_struct);


}
/***************************************************************************//**
 * @brief
 *  Data passed from Si1133 sensor to Mighty Gecko for enabling sensor peripheral.
 *
 * @details
 *  Part ID is set for Si1133 as well as passing in necessary parameters to enable I2C
 *  TypeDef Struct for calling I2C peripheral in app.c
 *
 * @note
 *  Necessary to pass in Si1133 part ID to communicate with Si1133 Data transfer.
 *
 * @param
 *  Parameters for each input to I2C_TypeDef Struct to pass into other function.
 *
 ******************************************************************************/


void Si1133_read(uint32_t RegisterAddress,uint32_t NumofBytes, uint32_t callback){
  uint32_t Device_Address = DEVICEADDRESS;

  I2C_Start(I2C1, true, NumofBytes, Device_Address,RegisterAddress, callback, &Si1133_read_result);

}
/***************************************************************************//**
 * @brief
 *  Si1133_get_partID returns the partID read by the Si1133 read function
 *
 * @details
 *  Utilizes the static local variable Si1133_read_result in order to return the result from I2C_start function.
 *
 * @note
 *
 * @param
 * None
 *
 ******************************************************************************/

uint32_t Si113_get_partID(void){
  uint32_t Read_Result = Si1133_read_result;

  return Read_Result;
}





