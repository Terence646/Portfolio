/**
 * @file scheduler.c
 * @author Terence Williams
 * @date 09/16/21
 * @brief Creates functions in order to manage scheduled events.
 *
 */

//******************************************************************************
// Include Files
//******************************************************************************

#include "scheduler.h"

//******************************************************************************
// Private Variables
//******************************************************************************

static unsigned int event_scheduled;

//******************************************************************************


/***************************************************************************//**
 * @brief
 *   Driver to managed different events going on.
 *
 * @details
 *   This routine is used in order to manage the order at which certian events need to happen.
 *   This is used when changing energy modes in order to minimize power consumption.
 *
 * @note
 *   The functions in this driver are protected by atomic operations. This means that they
 *   cannot be interrupted by the ISR once called. If an interrupt is triggered while
 *   inside one of these functions the interrupt will be executed once the processor leaves the function.
 *
 * @param[in] event
 *   The event parameter is used in all of the functions besides scheduler_open. This is because in
 *   the other functions, an event needs to be passed in specifically in order to add, remove or
 *   return the scheduled events. Compared to the scheduler_open function which just initializes the
 *   event_scheduled to 0.
 *
 *
 ******************************************************************************/

void scheduler_open(void)
{

  CORE_DECLARE_IRQ_STATE;
  CORE_ENTER_CRITICAL();

  event_scheduled = 0;

  CORE_EXIT_CRITICAL();

}

void add_scheduled_event(uint32_t event)
{

  CORE_DECLARE_IRQ_STATE;
  CORE_ENTER_CRITICAL();

    event_scheduled |= event;

  CORE_EXIT_CRITICAL();

}

void remove_scheduled_event(uint32_t event)
{

  CORE_DECLARE_IRQ_STATE;
  CORE_ENTER_CRITICAL();

    event_scheduled &= ~event;

  CORE_EXIT_CRITICAL();

}

uint32_t get_scheduled_events(void)
{
  unsigned int current_event;

  CORE_DECLARE_IRQ_STATE;
  CORE_ENTER_CRITICAL();

  current_event = event_scheduled;

  CORE_EXIT_CRITICAL();

  return current_event;

}

