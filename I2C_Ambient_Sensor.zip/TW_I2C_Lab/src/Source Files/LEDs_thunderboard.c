/**
 * @file LEDs_thunderboard.c
 * @author Terence Williams
 * @date 09/23/21
 * @brief Creates functions in order to enable LED's on the Thunderboard Sense 2.
 *
 */

//***********************************************************************************
// Include files
//***********************************************************************************
#include "LEDs_thunderboard.h"

//***********************************************************************************
// defined files
//***********************************************************************************


//***********************************************************************************
// Private variables
//***********************************************************************************
bool	rgb_enabled_status;

//***********************************************************************************
// Private functions
//***********************************************************************************


//***********************************************************************************
// Global functions
//***********************************************************************************

/***************************************************************************//**
 * @brief
 *   Driver to initalize and enable/disable the LED's on the Thunderboard Sense 2.
 *
 * @details
 *  This routine specifies the Pin output ports for each LED. Once the function rgb_init
 *  is called, it will set up out GPIO for our LED colors. In the leds_enabled function,
 *  we are setting up our pin outs depending on which LED and LED color is specified by the function call.
 *
 * @note
 *   The function leds_enabled can not only be used to enable an LED, but if passed in a boolean
 *   false as one of the parameters, can be used to disable the LED's as well.
 *
 * @param[in] leds
 *  This parameter is passed into the led_enabled function. This is used to
 *  choose which LED is going to be our output.
 *
 * @param[in] color
 *  This parameter is passed into the led_enabled function. This is used to
 *  choose which color LED we want being enabled on the specified LED output port.
 *
 * @param[in] enable
 *  This parameter is passed into the led_enabled function. This is a boolean True
 *  or False Value. If True, that specific LED color and output port will be enabled.
 *  If False, the LED color and output specified will be disabled.
 *
 ******************************************************************************/


void rgb_init(void) {
	rgb_enabled_status = false;
  GPIO_PinOutClear(RGB0_PORT,RGB0_PIN);
  GPIO_PinOutClear(RGB1_PORT,RGB1_PIN);
  GPIO_PinOutClear(RGB2_PORT,RGB2_PIN);
  GPIO_PinOutClear(RGB3_PORT,RGB3_PIN);
  GPIO_PinOutSet(RGB_ENABLE_PORT,RGB_ENABLE_PIN);
}

void leds_enabled(uint32_t leds, uint32_t color, bool enable){

    if ((color & COLOR_RED) && enable) {
      GPIO_PinOutSet(RGB_RED_PORT,RGB_RED_PIN);
    } else if ((color & COLOR_RED) && !enable) GPIO_PinOutClear(RGB_RED_PORT,RGB_RED_PIN);

    if ((color & COLOR_GREEN) && enable) {
      GPIO_PinOutSet(RGB_GREEN_PORT,RGB_GREEN_PIN);
    } else if ((color & COLOR_GREEN) && !enable)  GPIO_PinOutClear(RGB_GREEN_PORT,RGB_GREEN_PIN);

    if ((color & COLOR_BLUE) && enable) {
      GPIO_PinOutSet(RGB_BLUE_PORT,RGB_BLUE_PIN);
    } else if ((color & COLOR_BLUE) && !enable)  GPIO_PinOutClear(RGB_BLUE_PORT,RGB_BLUE_PIN);

		if ((leds & RGB_LED_0) && enable) {
			GPIO_PinOutSet(RGB0_PORT,RGB0_PIN);
		} else if ((leds & RGB_LED_0) && !enable) GPIO_PinOutClear(RGB0_PORT,RGB0_PIN);

		if ((leds & RGB_LED_1) && enable) {
			GPIO_PinOutSet(RGB1_PORT,RGB1_PIN);
		} else if ((leds & RGB_LED_1) && !enable)  GPIO_PinOutClear(RGB1_PORT,RGB1_PIN);

		if ((leds & RGB_LED_2) && enable) {
			GPIO_PinOutSet(RGB0_PORT,RGB2_PIN);
		} else if ((leds & RGB_LED_2) && !enable)  GPIO_PinOutClear(RGB2_PORT,RGB2_PIN);

		if ((leds & RGB_LED_3) && enable) {
			GPIO_PinOutSet(RGB3_PORT,RGB3_PIN);
		} else if ((leds & RGB_LED_3) && !enable)  GPIO_PinOutClear(RGB3_PORT,RGB3_PIN);

}

