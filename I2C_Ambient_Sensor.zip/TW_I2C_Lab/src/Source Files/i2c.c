/**
 * @file i2c.c
 * @author Terence Williams
 * @date 09/28/21
 * @brief
 *
 */

//***********************************************************************************
// Include files
//***********************************************************************************
#include "i2c.h"
//***********************************************************************************
// defined files
//***********************************************************************************


//***********************************************************************************
// global variables
//***********************************************************************************


//***********************************************************************************
// private structs
//***********************************************************************************

static I2C_STATE_MACHINE i2c0;
static I2C_STATE_MACHINE i2c1;

//***********************************************************************************
// function prototypes
//***********************************************************************************

static I2C_STATE_MACHINE   *i2c_local_struct;
//***********************************************************************************
// local function prototypes
//***********************************************************************************
void i2c_bus_reset(I2C_TypeDef *i2c_peripheral);

//void i2c_state_machine();


/***************************************************************************//**
 * @brief
 *  Function used to initialize and call I2C peripheral to start use within the driver code.
 *
 * @details
 *  Called in app.c, this function is called with other peripheral open functions to start all peripherals
 *  in use simultaneously.
 *
 * @note
 *  Function passes in I2C structs, storing and configuring and open values to correctly open I2C peripheral.
 *
 * @param
 *  I2C TypeDef *i2c, I2C struct, I2C_OPEN_STRUCT *i2c_setup for initializing I2C peripheral
 *
 ******************************************************************************/

void i2c_open(I2C_TypeDef *i2c_Address, I2C_OPEN_STRUCT *i2c_setup){
  I2C_Init_TypeDef i2c_values;  //Initializes local i2c struct

    if(i2c_Address == I2C0){
      CMU_ClockEnable(cmuClock_I2C0 , true);
      //initialize busy register
      i2c0.busy = false;
    }
    else if(i2c_Address == I2C1){
      CMU_ClockEnable(cmuClock_I2C1 , true);
      i2c1.busy = false;
      //initialize busy register
    }
    if ((i2c_Address->IF & 0x01) == 0) {
      i2c_Address->IFS = 0x01;
      EFM_ASSERT(i2c_Address->IF & 0x01);
      i2c_Address->IFC = 0x01;
    }
    else {
      i2c_Address->IFC = 0x01;
      EFM_ASSERT(!(i2c_Address->IF & 0x01));
    }
  i2c_values.enable = i2c_setup->enable;
  i2c_values.master = i2c_setup->master;
  i2c_values.freq = i2c_setup->freq;
  i2c_values.clhr = i2c_setup->clhr;
  i2c_values.refFreq = i2c_setup->refFreq;

  I2C_Init(i2c_Address,&i2c_values);

  i2c_Address->ROUTELOC0 = (i2c_setup->out_pin_routeSDA) | (i2c_setup->out_pin_routeSCL);

  /* Use the values from app_letimer_struct input argument to program the ROUTEPEN register for both
   * the OUT 0 Pin Enable (OUT0PEN) and the OUT 1 Pin Enable (OUT1PEN) in combination with the
   * enumeration of these pins utilizing boolean multiplication*/

  i2c_Address->ROUTEPEN = (I2C_ROUTEPEN_SDAPEN* i2c_setup->out_pin_SDA_en) | (I2C_ROUTEPEN_SCLPEN*i2c_setup->out_pin_SCL_en);

  i2c_bus_reset(i2c_Address);
  i2c_Address->IFC = i2c_Address->IF;
  i2c_Address->IEN |= I2C_IF_ACK;
  i2c_Address->IEN |= I2C_IF_RXDATAV;
  i2c_Address->IEN |= I2C_IF_MSTOP;

  if(i2c_Address == I2C0){
      NVIC_EnableIRQ(I2C0_IRQn);
    }
    else if(i2c_Address == I2C1){
        NVIC_EnableIRQ(I2C1_IRQn);
    }
}

/***************************************************************************//**
 * @brief
 *  Clears and resets the I2C bus, passing in values of the I2C struct to reset.
 *
 * @details
 *  Saving the state of the I2C, we can store interrupt flags and clear flags, buffers, and abort commands
 *  to reset the entire I2C peripheral.
 *
 * @note
 *  Using the OR command with both START and STOP in the I2C_CMD allows for reseting the I2C peripheral.
 *
 * @param
 *  I2C_TypeDef Struct with pointer *i2c, storing all variables to enable I2C peripheral.
 *
 ******************************************************************************/


void i2c_bus_reset(I2C_TypeDef *i2c_peripheral){
  uint16_t i2c_state;   //local variable to save i2c state
  i2c_peripheral->CMD = I2C_CMD_ABORT; //Abort command to reset the internal state machine
  i2c_state = i2c_peripheral->IEN;    // Saves the current state of the peripheral
  i2c_peripheral->IEN = false;

  i2c_peripheral->IFC = i2c_peripheral->IF;  //lowers the IF, IFC clear
  i2c_peripheral->CMD = I2C_CMD_CLEARTX;      //Clears the transmit buffer

  i2c_peripheral->CMD = I2C_CMD_START | I2C_CMD_STOP;
  while(!(i2c_peripheral->IF & I2C_IF_MSTOP));
  i2c_peripheral->IFC = i2c_peripheral->IF;

  i2c_peripheral->CMD = I2C_CMD_ABORT; //resets the micro-controller's I2c peripheral
  i2c_peripheral->IEN = i2c_state;
}

/***************************************************************************//**
 * @brief
 *  Checks which I2C peripheral is being used in order to instantiate the correct structure.
 *
 * @details
 *  Passing in the specific I2C peripheral I2C0 vs. I2C1, the function checks for the correct
 *  peripheral to configure for use with the Mighy Gecko.
 *
 * @note
 *  Using if statements and comparing the value of the *i2c the function checks the correct value
 *  to configure.
 *
 * @param
 *  Function parameters, I2C TypeDef *i2c, bool read_true, uint32_t num_of_bytes,
 *  uint32_t device_address, uint32_t register address, uint32_t callback, uint32_t *store_data
 *
 ******************************************************************************/


void I2C_Start(I2C_TypeDef *i2c, bool read_true, uint32_t numofBytes, uint32_t DeviceAddress,
               uint32_t RegisterAddress, uint32_t callback, uint32_t *StoreData){
//I2C_STATE_MACHINE   *i2c_local_struct;

//checks which i2c peripheral is being used in order to instantiate the correct structure

  if(i2c == I2C0){
      i2c_local_struct = &i2c0;
  }
  else if(i2c == I2C1){
      i2c_local_struct = &i2c1;
  }
      // initialize I2C state machine
  while(i2c_local_struct->busy); // assert i2c not busy
  EFM_ASSERT((i2c->STATE & _I2C_STATE_STATE_MASK) == I2C_STATE_STATE_IDLE);

  i2c_local_struct->i2c = i2c;
  i2c_local_struct->DeviceAddress = DeviceAddress;    //Initializes Structure
  i2c_local_struct->RegisterAddress = RegisterAddress;
  i2c_local_struct->StoreData = StoreData;
  i2c_local_struct->callback = callback;
  i2c_local_struct->numofBytes = numofBytes;
  i2c_local_struct->read_true = read_true;
  sleep_block_mode(EM2); //block from entering EM2 and set peripheral to busy
  i2c_local_struct->busy = true;
  i2c_local_struct->Current_i2c_State = initialize; // Initialize Current State of State Machine

  i2c->CMD = I2C_CMD_START; //Sends start bit
  i2c->TXDATA = DeviceAddress << 1 | 0;  // Shifts data over 1 place and inserts a 0 for write bit

}


/***************************************************************************//**
 * @brief
 *  IRQHandler for I2C1 peripheral, called when interrupts are flagged in I2C1 peripheral.
 *
 * @details
 *  Function calls, managing ACK interrupts from Si1133 sensor to monitor states
 *  to enter for next process.
 *
 * @note
 *  IRQHandler specific to the I2C1 peripheral, seperate from I2C0.
 *
 * @param
 *  No input parameters for this function.
 *
 ******************************************************************************/

void I2C1_IRQHandler(void){
  uint32_t int_flag;
  int_flag = I2C1->IF & I2C1->IEN;
  I2C1->IFC = int_flag;
  I2C1->IFS = true;
  if(I2C_IF_ACK & int_flag)
    {
      EFM_ASSERT(!(I2C1->IF & I2C_IF_ACK));
      i2c_ack_sm(&i2c1);
    }

  if(I2C_IF_RXDATAV & int_flag)
    {
//      EFM_ASSERT(!(I2C1->IF & I2C_IF_RXDATAV));
      i2c_read_sm(&i2c1);
    }

  if(I2C_IF_MSTOP & int_flag)
    {
      EFM_ASSERT(!(I2C1->IF & I2C_IF_MSTOP));
      i2c_stop_sm(&i2c1);
    }

}

/***************************************************************************//**
 * @brief
 *  IRQHandler for I2C0 peripheral, called when interrupts are flagged in I2C0 peripheral.
 *
 * @details
 *  Function calls, managing ACK interrupts from Si1133 sensor to monitor states
 *  to enter for next process.
 *
 * @note
 *  IRQHandler specific to the I2C0 peripheral, seperate from I2C1.
 *
 * @param
 *  None
 *
 ******************************************************************************/


void I2C0_IRQHandler(void){
  uint32_t int_flag;
  int_flag = I2C0->IF & I2C0->IEN;
  I2C0->IFC = int_flag;

  if(I2C_IF_ACK & int_flag)
    {
      EFM_ASSERT(!(I2C0->IF & I2C_IF_ACK));
      i2c_ack_sm(&i2c0);
    }

  if(I2C_IF_RXDATAV & int_flag)
    {
      EFM_ASSERT(!(I2C0->IF & I2C_IF_RXDATAV));
      i2c_read_sm(&i2c0);
    }

  if(I2C_IF_MSTOP & int_flag)
    {
      EFM_ASSERT(!(I2C0->IF & I2C_IF_MSTOP));
      i2c_stop_sm(&i2c0);
    }

}

/***************************************************************************//**
 * @brief
 *  Function accessing steps when changing states from an ACK from the Si1133 sensor
 *
 * @details
 *  Specific to ACK command received from Si1133 sensor.
 *
 * @note
 *  This function is specific to a particular state and interrupt command, other commands and interrupts have seperate functions.
 *
 * @param
 *  I2C_STATE_MACHINE *i2c_sm which holds the state of the I2C peripheral and configuring data.
 *
 ******************************************************************************/


void i2c_ack_sm(I2C_STATE_MACHINE *i2c_sm){

  switch(i2c_sm->Current_i2c_State){

          case initialize:
            i2c_sm->i2c->TXDATA = i2c_sm->RegisterAddress; //Sends Register Address
            i2c_sm->Current_i2c_State = send_RA;
            break;

          case send_RA:
            if(i2c_sm->read_true){  //Checks top see if we are in a write or read communication
                i2c_sm->i2c->CMD = I2C_CMD_START;
                i2c_sm->i2c->TXDATA = i2c_sm->DeviceAddress << 1 | 1; //Shifts Receiver Address over 1 and inserts a read bit
                i2c_sm->Current_i2c_State = send_DA;
            }
            else{
                EFM_ASSERT(false);
                i2c_sm->Current_i2c_State = transfer_data;
            }
            break;

          case send_DA:
            if(i2c_sm->read_true){
                i2c_sm->Current_i2c_State = transfer_data;
            }
            else{
            EFM_ASSERT(false);
            }
            break;

          case transfer_data:
            EFM_ASSERT(false);
            break;

          case send_stop:
            EFM_ASSERT(false);
            break;

          default:
            EFM_ASSERT(false);

  }

}

/***************************************************************************//**
 * @brief
 *  Function accessing steps when changing states from an read state within the Mighty Gecko
 *
 * @details
 *  Specific to read state within the Mighty Gecko to receive data from the Si1133 TXDATA buffer.
 *
 * @note
 *  This function is specific to a particular state and interrupt command, other commands and interrupts have seperate functions.
 *
 * @param
 *  I2C_STATE_MACHINE *i2c_sm which holds the state of the I2C peripheral and configuring data.
 *
 ******************************************************************************/


void i2c_read_sm(I2C_STATE_MACHINE *i2c_sm){

  switch(i2c_sm->Current_i2c_State){

      case initialize:
        EFM_ASSERT(false);
        break;

      case send_RA:
        EFM_ASSERT(false);
        break;

      case send_DA:
        EFM_ASSERT(false);
        break;

      case transfer_data:
    if(i2c_sm->read_true){
         if(i2c_sm->numofBytes > 0){
             *(i2c_sm->StoreData) = (i2c_sm->i2c->RXDATA)<<(8*(i2c_sm->numofBytes-1)); //either shift data over or make it an array
             i2c_sm->StoreData++;
             i2c_sm->numofBytes--;
             if(i2c_sm->numofBytes == 0){
                 i2c_sm->i2c->CMD = I2C_CMD_NACK;
                 i2c_sm->i2c->CMD = I2C_CMD_STOP;
                 i2c_sm->Current_i2c_State = send_stop;
             } else {
                 i2c_sm->i2c->CMD = I2C_CMD_ACK;
             }
         } else {
             EFM_ASSERT(false);
         }
     } else {
         EFM_ASSERT(false);
         }
         break;

      case send_stop:
        EFM_ASSERT(false);
        break;

      default:
        EFM_ASSERT(false);

  }
}
/*******************************************************************************
 * @brief
 *  Function accessing steps when changing states from a STOP command from the Mighty Gecko to end communication.
 * @details
 *  Specific to a STOP command called for the Mighty Gecko to transition states.
 *
 * @note
 *  This function is specific to a particular state and interrupt command, other commands and interrupts have seperate functions.
 *
 * @param
 *  I2C_STATE_MACHINE *i2c_sm which holds the state of the I2C peripheral and configuring data.
 *
 ******************************************************************************/

void i2c_stop_sm(I2C_STATE_MACHINE *i2c_sm){

  switch(i2c_sm->Current_i2c_State){

        case initialize:
          EFM_ASSERT(false);
          break;

        case send_RA:
          EFM_ASSERT(false);
          break;

        case send_DA:
          EFM_ASSERT(false);
          break;

        case transfer_data:
          EFM_ASSERT(false);
          break;

        case send_stop:
          add_scheduled_event(i2c_sm->callback);  // Sets the callback function
          sleep_unblock_mode(EM2);      //unblocks sleep mode
          i2c_sm->busy = false;     // Sets the busy bit to not busy
          break;

        default:
          EFM_ASSERT(false);
  }
}


