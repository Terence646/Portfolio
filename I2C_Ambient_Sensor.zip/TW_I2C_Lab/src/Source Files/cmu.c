/**
 * @file cmu.c
 * @author Terence Williams
 * @date 09/11/21
 * @brief Oscillator Enabling for Clock Tree
 *
 */
//***********************************************************************************
// Include files
//***********************************************************************************
#include "cmu.h"

//***********************************************************************************
// defined files
//***********************************************************************************


//***********************************************************************************
// Private variables
//***********************************************************************************


//***********************************************************************************
// Private functions
//***********************************************************************************


//***********************************************************************************
// Global functions
//***********************************************************************************

/***************************************************************************//**
 * @brief
 *  Within the cmu.c module, this is responsible for enabling all oscillators
 *  and routing the clock tree for the application.
 *
 * @details
 *  In doing so, we use these oscillators through the clock tree for intended
 *  specifications to blink our green LED else where in the project.
 *
 *  We disable two oscillators and enable our intended one.
 *
 * @note
 *  No requirement to enable the ULFRCO oscillator. With this we have set our
 *  clock tree which can be found in the reference manual.
 *
 ******************************************************************************/

void cmu_open(void){

    CMU_ClockEnable(cmuClock_HFPER, true);

    // By default, LFRCO is enabled, disable the LFRCO oscillator
    // Disable the LFRCO oscillator
    // What is the enumeration required for LFRCO?
    // It can be found in the online HAL documentation
    CMU_OscillatorEnable(cmuOsc_LFRCO   , false, false);

    // Disable the LFXO oscillator
    // What is the enumeration required for LFXO?
    // It can be found in the online HAL documentation
    CMU_OscillatorEnable(cmuOsc_LFXO  , false, false);

//     No requirement to enable the ULFRCO oscillator.  It is always enabled in EM0-4H1

    // Route LF clock to the LF clock tree
    // What is the enumeration required to placed the ULFRCO onto the proper clock branch?
    // It can be found in the online HAL documentation
    CMU_ClockSelectSet(cmuClock_LFA  , cmuSelect_ULFRCO);    // routing ULFRCO to proper Low Freq clock tree

    // What is the proper enumeration to enable the clock tree onto the LE clock branches?
    // It can be found in the Assignment 2 documentation
    CMU_ClockEnable(cmuClock_CORELE, true);


//    CMU_ClockEnable(CMU_HFPERCLKEN0_I2C0);


}

