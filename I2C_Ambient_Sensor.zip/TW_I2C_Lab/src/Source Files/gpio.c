/**
 * @file gpio.c
 * @author Terence Williams
 * @date 09/11/21
 * @brief GPIO sets our input and output pins for utilizing the green LED
 *
 */

//***********************************************************************************
// Include files
//***********************************************************************************
#include "gpio.h"

//***********************************************************************************
// defined files
//***********************************************************************************


//***********************************************************************************
// global variables
//***********************************************************************************


//***********************************************************************************
// function prototypes
//***********************************************************************************


//***********************************************************************************
// functions
//***********************************************************************************

/***************************************************************************//**
 * @brief
 *  GPIO sets our input and output pins for utilizing the green LED.
 *
 * @details
 *  Setting the pins, drive mode, and pin mode allow for configuring our LED.
 *  Here we can then direct our PWM outputs to the correct port and gain the
 *  LED output.
 *
 * @note
 *
 *
 ******************************************************************************/

void gpio_open(void){

  CMU_ClockEnable(cmuClock_GPIO, true);

	// Configure LED pins
	GPIO_DriveStrengthSet(LED_RED_PORT, LED_RED_DRIVE_STRENGTH);
	GPIO_PinModeSet(LED_RED_PORT, LED_RED_PIN, LED_RED_GPIOMODE, LED_RED_DEFAULT);

	GPIO_DriveStrengthSet(LED_GREEN_PORT, LED_GREEN_DRIVE_STRENGTH);
	GPIO_PinModeSet(LED_GREEN_PORT, LED_GREEN_PIN, LED_GREEN_GPIOMODE, LED_GREEN_DEFAULT);

	// Set RGB LED gpio pin configurations
	 GPIO_PinModeSet(RGB_ENABLE_PORT, RGB_ENABLE_PIN, gpioModePushPull,
	 RGB_DEFAULT_OFF);
	 GPIO_PinModeSet(RGB0_PORT, RGB0_PIN, gpioModePushPull, RGB_DEFAULT_OFF);
	 GPIO_PinModeSet(RGB1_PORT, RGB1_PIN, gpioModePushPull, RGB_DEFAULT_OFF);
	 GPIO_PinModeSet(RGB2_PORT, RGB2_PIN, gpioModePushPull, RGB_DEFAULT_OFF);
	 GPIO_PinModeSet(RGB3_PORT, RGB3_PIN, gpioModePushPull, RGB_DEFAULT_OFF);
	 GPIO_PinModeSet(RGB_RED_PORT, RGB_RED_PIN, gpioModePushPull, COLOR_DEFAULT_OFF);
	 GPIO_PinModeSet(RGB_GREEN_PORT, RGB_GREEN_PIN, gpioModePushPull,
	 COLOR_DEFAULT_OFF);
	 GPIO_PinModeSet(RGB_BLUE_PORT, RGB_BLUE_PIN, gpioModePushPull, COLOR_DEFAULT_OFF);

	 //GPIO for UV/Ambient Light Sensor
	 GPIO_DriveStrengthSet(SI1133_SENSOR_EN_PORT, SENSOR_ENABLE_DRIVE_STRENGTH);
	 GPIO_PinModeSet(SI1133_SENSOR_EN_PORT,SI1133_SENSOR_EN_PIN,gpioModePushPull,true); //Sensor Enable Pin set, DEFAULT == OFF
	 GPIO_PinModeSet(SI1133_SCL_PORT,SI1133_SCL_PIN, gpioModeWiredAnd,true); //SCL, Serial Clock Pin set
	 GPIO_PinModeSet(SI1133_SDA_PORT,SI1133_SDA_PIN,gpioModeWiredAnd,true); //SDA, Serial Data pin set

}
