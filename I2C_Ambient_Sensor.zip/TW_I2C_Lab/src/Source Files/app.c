/**
 * @file app.c
 * @author Terence Williams
 * @date 09/11/21
 * @brief Defining our letimer_pwm_struct for passing values into the rest of the modules
 *
 */

//***********************************************************************************
// Include files
//***********************************************************************************
#include "app.h"
//***********************************************************************************
// defined files
//***********************************************************************************

//***********************************************************************************
// Private variables
//***********************************************************************************

static int LED_Color;

//***********************************************************************************
// Private functions
//***********************************************************************************

static void app_letimer_pwm_open(float period, float act_period, uint32_t out0_route, uint32_t out1_route);


//***********************************************************************************
// Global functions
//***********************************************************************************

/***************************************************************************//**
 * @brief
 *  Defining our letimer_pwm_struct for passing values into the rest of the modules.
 *
 * @details
 *  Using our separate functions,we define our struct as well as declare the
 *  functions that the values from these structures are going to be passed into in
 *  other modules such as letimer.c.
 *
 * @note
 *  Used in multiple other modules for function calls.
 *
 ******************************************************************************/

void app_peripheral_setup(void){
  cmu_open();
  gpio_open();
  scheduler_open();
  sleep_open();
  Si1133_i2c_open();
  LED_INIT();
  app_letimer_pwm_open(PWM_PER, PWM_ACT_PER, PWM_ROUTE_0, PWM_ROUTE_1);
  letimer_start(LETIMER0, true);  //This command will initiate the start of the LETIMER0
}

void LED_INIT(void){
  rgb_init();
  LED_Color = 0;
}

/***************************************************************************//**
 * @brief
 *  Initiate the start of the LETIMER0
 *
 * @details
 *  Within the app_peripheral_setup function, we pass in our PWM settings such
 *  as our period and active period which relies on the COMP0 and COMP1 values.
 *
 * @note
 *  This also deals with the routing of our PWM with our repeat and other
 *  values. The function below, with app_letimer_pwm_open allows for calling the
 *  letimer open functions and ensures that our PWM operation is correct.
 *
 * @param[in] period + act_period
 *  Period + Active Period. This is the values for our COMP0 and COMP1
 *  registers. This deals with how long the LED is on within the actual period
 *  of our LETIMER oscillator.
 *
 * @param[in] out0_route + out1_route
 *  This deals with passing in the correct pin routes to our letimer_pwm_struct.
 *  We later use this struct in other functions for correctly setting our
 *  letimer.
 *
 *
 ******************************************************************************/

void app_letimer_pwm_open(float period, float act_period, uint32_t out0_route, uint32_t out1_route)
{
  // Initializing LETIMER0 for PWM operation by creating the
  // letimer_pwm_struct and initializing all of its elements
  // APP_LETIMER_PWM_TypeDef is defined in letimer.h
  APP_LETIMER_PWM_TypeDef   letimer_pwm_struct;

  letimer_pwm_struct.debugRun = false;
  letimer_pwm_struct.enable = false;
  letimer_pwm_struct.out_pin_route0 = out0_route;
  letimer_pwm_struct.out_pin_route1 = out1_route;
  letimer_pwm_struct.out_pin_0_en = false;
  letimer_pwm_struct.out_pin_1_en = false;
  letimer_pwm_struct.period = period;
  letimer_pwm_struct.active_period = act_period;
  letimer_pwm_struct.comp0_irq_enable = false;
  letimer_pwm_struct.comp0_cb = LETIMER0_COMP0_CB;
  letimer_pwm_struct.comp1_irq_enable = true;
  letimer_pwm_struct.comp1_cb = LETIMER0_COMP1_CB;
  letimer_pwm_struct.uf_irq_enable = false;
  letimer_pwm_struct.uf_cb = LETIMER0_UF_CB;
  letimer_pwm_open(LETIMER0, &letimer_pwm_struct);
}

// Want to initialize the scheduled events before running code to manipulate them.

/***************************************************************************//**
 * @brief
 *  View scheduled interrupt flags for the UF register. This allows interrupts
 *  to be serviced appropriately.
 *
 * @details
 *  Within the function, this calls the value of LED_COLOR which indicates
 *  which LED color is active and enables that specific color then cycles to
 *  the next color to be accessed the next clock cycle.
 *
 * @note
 *  Within the call back function, this function is specific to the underflow
 *  or UF register that deals with when the timer underflows and resets the
 *  count.
 *
 * @param[in]
 *  No parameters are passed in, and calls on other functions.
 *
 ******************************************************************************/


void scheduled_letimer0_uf_cb(void)
{

  // CODE FROM BEFORE LAB 4
//  if(LED_Color == 0){
//     leds_enabled(RGB_LED_1,COLOR_RED,false);
//     LED_Color++;
//  }
//  else if(LED_Color == 1){
//       leds_enabled(RGB_LED_1,COLOR_GREEN,false);
//       LED_Color++;
//   }
//  else if(LED_Color == 2){
//       leds_enabled(RGB_LED_1,COLOR_BLUE,false);
//       LED_Color = 0;
//   }
  // EFM_ASSERT(!(get_scheduled_events() & LETIMER0_UF_CB));

  // If this asset is not called, we can see that the correct bit in the
  // LETIMER0_UF_CB was set giving reason to enter this function. If this gives
  // an error, we can see that we entered this function due to one of our other
  // scheduled interrupts and perhaps we did not correcly finish an atomic
  // operation.

}

/*******************************************************************************
 * @brief
 *  Reads the value of the Si1133 Callback function for determining the value of the Callback
 *  functions result.
 *
 * @details
 *  Based on the value recieved back, the function compares with the defined expected result from earlier and
 *  manipulates the output of the LED based on this comparison.
 *
 * @note
 *  Only toggles the RED and GREEN LEDs on the Mighty Gecko and indicates a correct vs. an incorrect value.
 *
 * @param[in]
 *  No parameters are passed in.
 *
 ******************************************************************************/

void scheduled_Si1133_reg_read_cb(void){
  uint32_t readResult;
  readResult = Si113_get_partID();
  if(readResult == ExpectedResult)
    leds_enabled(RGB_LED_1, COLOR_GREEN, true);;
   if(readResult != ExpectedResult)
       leds_enabled(RGB_LED_1,COLOR_RED,true);
}

void scheduled_letimer0_comp0_cb(void)
{

  EFM_ASSERT(false);

}

/***************************************************************************//**
 * @brief
 *  Enabled the specific color to the LED1 to be lit depending on the value of
 *  LED_COLOR that was set within the underflow register scheduler.
 *
 * @details
 *  Takes the value of LED_COLOR and determines which LED color to light.
 *
 * @note
 *  This function is dealt within the COMP1 register and could be used in the
 *  same manner for COMP0.
 *
 * @param[in]
 *  No parameters are passed in.
 *
 ******************************************************************************/

void scheduled_letimer0_comp1_cb(void)
{
  Si1133_read(REGISTERADDRESS ,BYTES, SI1133_REG_READ_CB);
  // CODE FROM BEFORE LAB 4
//  if(LED_Color == 0)
//     leds_enabled(RGB_LED_1,COLOR_RED,true);
//   if(LED_Color == 1)
//       leds_enabled(RGB_LED_1,COLOR_GREEN,true);
//   if(LED_Color == 2)
//       leds_enabled(RGB_LED_1,COLOR_BLUE,true);
//  //EFM_ASSERT(!(get_scheduled_events() & LETIMER0_COMP1_CB));


}
