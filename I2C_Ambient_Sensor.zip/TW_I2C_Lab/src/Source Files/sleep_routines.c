/**
 * @file sleep_routines.c
 * @author Terence Williams
 * @date 09/21/21
 * @brief Defines functions to manage the sleep routines of the Thunderboard Sense 2
 * depending on what energy mode we are in.
 *
 */

//******************************************************************************
// Include Files
//******************************************************************************

#include "sleep_routines.h"

//******************************************************************************
// Private Variables
//******************************************************************************

/**************************************************************************
* @file sleep_routines.c
***************************************************************************
* @section License
* <b>(C) Copyright 2015 Silicon Labs, http://www.silabs.com</b>
***************************************************************************
*
* Permission is granted to anyone to use this software for any purpose,
* including commercial applications, and to alter it and redistribute it
* freely, subject to the following restrictions:
*
* 1. The origin of this software must not be misrepresented; you must not
* claim that you wrote the original software.
* 2. Altered source versions must be plainly marked as such, and must not be
* misrepresented as being the original software.
* 3. This notice may not be removed or altered from any source distribution.
*
* DISCLAIMER OF WARRANTY/LIMITATION OF REMEDIES: Silicon Labs has no
* obligation to support this Software. Silicon Labs is providing the
* Software "AS IS", with no express or implied warranties of any kind,
* including, but not limited to, any implied warranties of merchantability
* or fitness for any particular purpose or warranties against infringement
* of any proprietary rights of a third party.
*
* Silicon Labs will not be liable for any consequential, incidental, or
* special damages, or any other relief, or for any claim by any third party,
* arising from your use of this Software.
*
**************************************************************************/

static int lowest_energy_mode[MAX_ENERGY_MODES];

void enter_sleep(void) {
  CORE_DECLARE_IRQ_STATE;
  CORE_ENTER_CRITICAL();

    if(lowest_energy_mode[EM0] > 0){
    }
    if(lowest_energy_mode[EM1] > 0){
       }
    if(lowest_energy_mode[EM2] > 0){
           EMU_EnterEM1();
       }
    if(lowest_energy_mode[EM3] > 0){
           EMU_EnterEM2(true);
       }
    else{
        EMU_EnterEM3(true);
    }

  CORE_EXIT_CRITICAL();
}

uint32_t current_block_energy_mode(void){

  int i = 0;
//  CORE_DECLARE_IRQ_STATE;
//  CORE_ENTER_CRITICAL();

  while(i < MAX_ENERGY_MODES){
      if(lowest_energy_mode[i] !=0){
          return i;
      }
      i++;
  }

//  CORE_EXIT_CRITICAL();
  return(MAX_ENERGY_MODES - 1);
}

void sleep_block_mode(uint32_t EM){
  CORE_DECLARE_IRQ_STATE;
  CORE_ENTER_CRITICAL();

  lowest_energy_mode[EM]++;
  CORE_EXIT_CRITICAL();
  EFM_ASSERT (lowest_energy_mode[EM] < 5);
}

void sleep_unblock_mode(uint32_t EM){
  CORE_DECLARE_IRQ_STATE;
  CORE_ENTER_CRITICAL();


  lowest_energy_mode[EM]--;
  CORE_EXIT_CRITICAL();
  EFM_ASSERT (lowest_energy_mode[EM] >= 0);
}

void sleep_open(void){
  for(int i = 0; i < MAX_ENERGY_MODES;i++){
      lowest_energy_mode[i] = 0;
  }

}


